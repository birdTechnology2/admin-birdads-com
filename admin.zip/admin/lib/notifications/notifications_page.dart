import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../main_menu.dart';

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _bulkMessageController = TextEditingController();
  String _searchQuery = '';

  Future<void> _sendNotification(String message, String email) async {
    try {
      await FirebaseFirestore.instance.collection('notifications').add({
        'message': message,
        'email': email,
        'timestamp': FieldValue.serverTimestamp(),
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم إرسال الإشعار بنجاح'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ أثناء إرسال الإشعار'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _sendBulkNotification(String message) async {
    final clients = await FirebaseFirestore.instance.collection('clients').get();
    for (var doc in clients.docs) {
      final data = doc.data();
      await _sendNotification(message, data['email']);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('الإشعارات'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // حقل البحث
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'بحث عن العميل بالاسم أو البريد الإلكتروني',
                  suffixIcon: IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      setState(() {
                        _searchQuery = _searchController.text.trim();
                      });
                    },
                  ),
                ),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('clients').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('حدث خطأ'));
                  }
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  final clients = snapshot.data!.docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final firstName = data['firstName']?.toString().toLowerCase() ?? '';
                    final lastName = data['lastName']?.toString().toLowerCase() ?? '';
                    final email = data['email']?.toString().toLowerCase() ?? '';
                    final query = _searchQuery.toLowerCase();
                    return firstName.contains(query) || lastName.contains(query) || email.contains(query);
                  }).toList();
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      border: TableBorder.all(),
                      columns: [
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'الاسم الأول',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'الاسم الأخير',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'البريد الإلكتروني',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'إرسال إشعار',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                      rows: clients.asMap().entries.map((entry) {
                        final index = entry.key;
                        final doc = entry.value;
                        final data = doc.data() as Map<String, dynamic>;
                        final messageController = TextEditingController();
                        final rowColor = index % 2 == 0 ? Colors.white : Colors.grey[200];

                        return DataRow(
                          color: MaterialStateProperty.resolveWith<Color?>(
                                (Set<MaterialState> states) {
                              return rowColor;
                            },
                          ),
                          cells: [
                            DataCell(Text(data['firstName'] ?? '')),
                            DataCell(Text(data['lastName'] ?? '')),
                            DataCell(Text(data['email'] ?? '')),
                            DataCell(
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      width: 200,
                                      child: TextField(
                                        controller: messageController,
                                        decoration: InputDecoration(
                                          labelText: 'رسالة',
                                        ),
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.send),
                                    onPressed: () {
                                      final message = messageController.text;
                                      if (message.isNotEmpty) {
                                        _sendNotification(message, data['email']);
                                        messageController.clear();
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
            // حقل إرسال إشعار لجميع العملاء
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    controller: _bulkMessageController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'إرسال إشعار لجميع العملاء',
                    ),
                    maxLines: 3,
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      final message = _bulkMessageController.text;
                      if (message.isNotEmpty) {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text('تأكيد إرسال الإشعار'),
                            content: Text('هل أنت متأكد من أنك تريد إرسال "$message" إلى جميع العملاء؟'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.of(context).pop(),
                                child: Text('إلغاء'),
                              ),
                              TextButton(
                                onPressed: () {
                                  _sendBulkNotification(message);
                                  Navigator.of(context).pop();
                                  _bulkMessageController.clear();
                                },
                                child: Text('نعم'),
                              ),
                            ],
                          ),
                        );
                      }
                    },
                    child: Text('إرسال الإشعار للجميع'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      drawer: MainMenu(),
    );
  }
}

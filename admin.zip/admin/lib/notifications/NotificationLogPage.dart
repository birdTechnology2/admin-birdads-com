import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../main_menu.dart';

class NotificationLogPage extends StatefulWidget {
  @override
  _NotificationLogPageState createState() => _NotificationLogPageState();
}

class _NotificationLogPageState extends State<NotificationLogPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('سجل الإشعارات'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('notifications').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('حدث خطأ'));
                  }
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  final notifications = snapshot.data!.docs;
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      border: TableBorder.all(),
                      columns: [
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'UID',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'الاسم الأول',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'الاسم الأخير',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'الإيميل',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'التوقيت',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Container(
                            color: Colors.lightBlue,
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'المرسل',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                      rows: notifications.asMap().entries.map((entry) {
                        final index = entry.key;
                        final doc = entry.value;
                        final data = doc.data() as Map<String, dynamic>;
                        final rowColor = index % 2 == 0 ? Colors.white : Colors.grey[200];

                        return DataRow(
                          color: MaterialStateProperty.resolveWith<Color?>(
                                (Set<MaterialState> states) {
                              return rowColor;
                            },
                          ),
                          cells: [
                            DataCell(Text(doc.id)),
                            DataCell(Text(data['firstName'] ?? '')),
                            DataCell(Text(data['lastName'] ?? '')),
                            DataCell(Text(data['email'] ?? '')),
                            DataCell(Text((data['timestamp'] as Timestamp).toDate().toString())),
                            DataCell(Text(data['sender'] ?? '')),
                          ],
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      drawer: MainMenu(),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../main_menu.dart';

class ClientsPage extends StatelessWidget {
  final CollectionReference clients = FirebaseFirestore.instance.collection('clients');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('العملاء'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: clients.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('حدث خطأ ما');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          final data = snapshot.requireData;

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                DataColumn(
                  label: Text(
                    'الاسم الأول',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'الاسم الأخير',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'البريد الإلكتروني',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'تاريخ إنشاء الحساب',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'آخر تسجيل دخول',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
              ],
              rows: data.docs.map((client) {
                final clientData = client.data() as Map<String, dynamic>; // تأكيد أن البيانات خريطة

                return DataRow(cells: [
                  DataCell(Text(clientData['firstName'] ?? '')),
                  DataCell(Text(clientData['lastName'] ?? '')),
                  DataCell(Text(clientData['email'] ?? '')),
                  DataCell(Text(clientData['createdAt'] != null ? (clientData['createdAt'] as Timestamp).toDate().toString() : '')),
                  DataCell(Text(clientData['lastLogin'] != null ? (clientData['lastLogin'] as Timestamp).toDate().toString() : '')),
                ]);
              }).toList(),
              headingRowColor: MaterialStateProperty.resolveWith((states) => Colors.grey.shade200),
              border: TableBorder.all(color: Colors.grey),
            ),
          );
        },
      ),
      drawer: MainMenu(),
    );
  }
}

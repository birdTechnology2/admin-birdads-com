import 'package:flutter/material.dart';
import 'router.dart'; // تأكد من أنك تستورد ملف التوجيه الصحيح

void main() {
  runApp(App());
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routeInformationParser: router.routeInformationParser,
      routerDelegate: router.routerDelegate,
      routeInformationProvider: router.routeInformationProvider, // تأكد من إضافة هذا السطر
      title: 'Your Project',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'clients/clients_page.dart';
import 'customer_complaints/customer_complaints_page.dart';
import 'notifications/NotificationLogPage.dart';
import 'notifications/notifications_page.dart';
import 'support_messages/support_messages_page.dart';
import 'transfers/transfers_page.dart';
import 'home_page.dart'; // استيراد الصفحة الرئيسية

final GoRouter router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => HomePage(), // تحديد الصفحة الرئيسية
    ),
    GoRoute(
      path: '/clients',
      builder: (context, state) => ClientsPage(),
    ),
    GoRoute(
      path: '/transfers',
      builder: (context, state) => TransfersPage(),
    ),
    GoRoute(
      path: '/notifications',
      builder: (context, state) => NotificationsPage(),
    ),
    GoRoute(
      path: '/notification_log',
      builder: (context, state) => NotificationLogPage(),
    ),
    GoRoute(
      path: '/support_messages',
      builder: (context, state) => SupportMessagesPage(),
    ),
    GoRoute(
      path: '/customer_complaints',
      builder: (context, state) => CustomerComplaintsPage(),
    ),
  ],
);

import 'package:flutter/material.dart';
import 'main_menu.dart'; // تأكد من استيراد ملف القائمة الرئيسية

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('الصفحة الرئيسية'),
      ),
      body: Center(
        child: Text('مرحبًا بك في التطبيق الخاص بك!'),
      ),
      drawer: MainMenu(),
    );
  }
}

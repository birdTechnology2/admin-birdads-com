import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class MainMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Text(
              'القائمة الرئيسية',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('العملاء'),
            onTap: () {
              context.go('/clients');
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.transfer_within_a_station),
            title: Text('التحويلات'),
            onTap: () {
              context.go('/transfers');
              Navigator.pop(context);
            },
          ),
          ExpansionTile(
            leading: Icon(Icons.notifications),
            title: Text('الإشعارات'),
            children: [
              ListTile(
                leading: Icon(Icons.send),
                title: Text('إرسال إشعار للعملاء'),
                onTap: () {
                  context.go('/notifications');
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.list),
                title: Text('قائمة الإشعارات'),
                onTap: () {
                  context.go('/notification_log');
                  Navigator.pop(context);
                },
              ),
            ],
          ),
          ListTile(
            leading: Icon(Icons.message),
            title: Text('رسائل الدعم'),
            onTap: () {
              context.go('/support_messages');
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.report_problem),
            title: Text('شكاوى العملاء'),
            onTap: () {
              context.go('/customer_complaints');
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}

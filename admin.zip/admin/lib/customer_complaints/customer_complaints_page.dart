import 'package:flutter/material.dart';
import '../main_menu.dart'; // تأكد من استيراد MainMenu

class CustomerComplaintsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('شكاوى العملاء'),
      ),
      body: Center(
        child: Text('صفحة شكاوى العملاء'),
      ),
      drawer: MainMenu(), // إضافة القائمة الرئيسية كـ Drawer
    );
  }
}

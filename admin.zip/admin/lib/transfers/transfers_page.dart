import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:html' as html;
import 'package:intl/intl.dart'; // إضافة مكتبة intl
import '../main_menu.dart';

class TransfersPage extends StatefulWidget {
  @override
  _TransfersPageState createState() => _TransfersPageState();
}

class _TransfersPageState extends State<TransfersPage> {
  final Map<String, TextEditingController> _controllers = {};
  String _searchQuery = ''; // متغير لحفظ نص البحث

  @override
  void dispose() {
    _controllers.forEach((key, controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('التحويلات'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'بحث',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection('transactions').snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('حدث خطأ ما!'));
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('لا توجد تحويلات'));
                }

                List<QueryDocumentSnapshot> docs = snapshot.data!.docs;

                // تطبيق الفلترة
                if (_searchQuery.isNotEmpty) {
                  docs = docs.where((doc) {
                    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
                    return data['firstName'].toString().contains(_searchQuery) ||
                        data['lastName'].toString().contains(_searchQuery) ||
                        data['email'].toString().contains(_searchQuery) ||
                        data['amount'].toString().contains(_searchQuery) ||
                        DateFormat('yyyy-MM-dd – HH:mm').format((data['timestamp'] as Timestamp).toDate()).contains(_searchQuery);
                  }).toList();
                }

                // فرز المعاملات بحيث تظهر الجديدة أولًا
                docs.sort((a, b) {
                  Timestamp timestampA = a['timestamp'] as Timestamp;
                  Timestamp timestampB = b['timestamp'] as Timestamp;
                  return timestampB.compareTo(timestampA);
                });

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SingleChildScrollView(
                    child: DataTable(
                      columns: _buildColumns(),
                      rows: _buildRows(docs),
                      headingRowColor: MaterialStateColor.resolveWith((states) => Colors.grey.shade300),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black),
                      dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                      dataTextStyle: TextStyle(fontSize: 14, color: Colors.black),
                      dividerThickness: 1.0,
                      border: TableBorder(
                        verticalInside: BorderSide(width: 1, color: Colors.grey, style: BorderStyle.solid),
                        horizontalInside: BorderSide(width: 1, color: Colors.grey, style: BorderStyle.solid),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      drawer: MainMenu(),
    );
  }

  List<DataColumn> _buildColumns() {
    return [
      DataColumn(label: Text('رقم العملية')),
      DataColumn(label: Text('الاسم الأول')),
      DataColumn(label: Text('الاسم الأخير')),
      DataColumn(label: Text('البريد الإلكتروني')),
      DataColumn(label: Text('المبلغ')),
      DataColumn(label: Text('الملاحظات')),
      DataColumn(label: Text('إيصال التحويل')),
      DataColumn(label: Text('إجمالي الرصيد')),
      DataColumn(label: Text('إضافة رصيد')),
      DataColumn(label: Text('التوقيت')), // العمود الجديد
    ];
  }

  List<DataRow> _buildRows(List<QueryDocumentSnapshot> docs) {
    return docs.asMap().entries.map((entry) {
      int index = entry.key;
      DocumentSnapshot document = entry.value;
      Map<String, dynamic> data = document.data() as Map<String, dynamic>;

      if (!_controllers.containsKey(document.id)) {
        _controllers[document.id] = TextEditingController();
      }

      DateTime timestamp = (data['timestamp'] as Timestamp).toDate(); // استرجاع التوقيت
      String formattedDate = DateFormat('yyyy-MM-dd – HH:mm').format(timestamp); // تنسيق التوقيت

      return DataRow(
        color: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
          if (index % 2 == 0) {
            return Colors.grey.shade200;
          }
          return Colors.white;
        }),
        cells: [
          DataCell(Text(data['serialNumber'].toString())), // تأكد من تحويل القيم إلى String
          DataCell(Text(data['firstName'] ?? '')),
          DataCell(Text(data['lastName'] ?? '')),
          DataCell(Text(data['email'] ?? '')),
          DataCell(Text(data['amount'].toString())), // تأكد من تحويل القيم إلى String
          DataCell(Text(data['note'] ?? '')),
          DataCell(
            data['screenshotUrl'] != null
                ? InkWell(
              child: Text(
                'عرض الإيصال',
                style: TextStyle(color: Colors.blue, decoration: TextDecoration.underline),
              ),
              onTap: () => _launchURL(data['screenshotUrl']),
            )
                : Text('لا يوجد'),
          ),
          DataCell(Text((data['total_balance'] ?? 0).toString())), // تأكد من تحويل القيم إلى String
          DataCell(
            TextField(
              controller: _controllers[document.id],
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
              ),
              onSubmitted: (value) => _updateBalance(data['email'], value),
            ),
          ),
          DataCell(Text(formattedDate)), // عرض التوقيت
        ],
      );
    }).toList();
  }

  void _launchURL(String url) async {
    if (kIsWeb) {
      html.window.open(url, '_blank');
    } else {
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }
  }

  Future<void> _updateBalance(String email, String value) async {
    int addedBalance = int.tryParse(value) ?? 0;

    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('transactions')
        .where('email', isEqualTo: email)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      for (var doc in querySnapshot.docs) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        int currentBalance = data['total_balance'] ?? 0;
        int newBalance = currentBalance + addedBalance;

        await FirebaseFirestore.instance.collection('transactions').doc(doc.id).update({
          'total_balance': newBalance,
        });
      }
    }

    _controllers.forEach((key, controller) => controller.clear());
  }

  Future<void> _addTransaction(String email, int amount, String firstName, String lastName, String note, String screenshotUrl) async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('transactions').get();
    int nextSerialNumber = querySnapshot.docs.length + 1;

    await FirebaseFirestore.instance.collection('transactions').add({
      'serialNumber': nextSerialNumber,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'amount': amount,
      'note': note,
      'screenshotUrl': screenshotUrl,
      'total_balance': 0,
      'timestamp': FieldValue.serverTimestamp(), // إضافة التوقيت إلى المستند
    });
  }
}
